tailwind.config = {
  theme: {
    extend: {
      colors: {
        custom: {
          blue: "#3b83f6",
        },
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
      },
    },
  },
};
